<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImagenNoticias extends Model
{
    use HasFactory;

    // Opcional
    // protected $table = 'imagen_noticias';
}
